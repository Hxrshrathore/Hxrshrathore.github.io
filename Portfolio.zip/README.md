# [Front-End Web-developer Website]

A portfolio web site completely made in html css and js from ground up.

#### Watch it live here - [hxrshrathore.me](https://hxrshrathore.me/)

<br>

## This is how it looks

<br>

### In dark mode

![In dark mode](./preview/hailee-dark.png)

### In light mode

![In light mode](./preview/hailee-light.png)
