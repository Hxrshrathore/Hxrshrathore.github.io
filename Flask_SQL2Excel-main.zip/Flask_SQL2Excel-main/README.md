# Flask_SQL2Excel
A Flask Based Application to Export data as a EXCEL file from a MYSQL Server
